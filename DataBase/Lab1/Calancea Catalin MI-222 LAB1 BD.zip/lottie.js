const lottieAnimation2 = lottie.loadAnimation({
    container: document.getElementById("lottie-animation2"),
    renderer: "svg",
    loop: true, // Set loop to true to play the animation repeatedly
    autoplay: true,
    path: "animation_lnmyfsfm.json", // Replace with your animation file path
  });